<?php
/*
Plugin Name: Property Weather Plugin
Description: A plugin to manage properties and display weather data based on their location.
Version: 1.0
Author: Santosh Bhumkar
*/

if (!defined('ABSPATH')) {
    exit; 
}

// Ensure settings.php is properly included
$settings_file = plugin_dir_path(__FILE__) . 'settings.php';
if (file_exists($settings_file)) {
    require_once $settings_file;
} else {
    wp_die("The settings.php file could not be found.");
}

//  Enqueue JavaScript file and localize AJAX URL
function pw_enqueue_scripts() {
    wp_enqueue_script(
        'pw-weather-js',
        plugin_dir_url(__FILE__) . 'weather.js',
        array('jquery'), // Dependencies
        null,
        true // Load in the footer
    );
}
add_action('wp_enqueue_scripts', 'pw_enqueue_scripts');

// Register Custom Post Type: Property
function pw_register_property_post_type() {
    register_post_type('property', array(
        'label' => 'Properties',
        'public' => true,
        'supports' => array('title', 'thumbnail'),
        'menu_icon' => 'dashicons-admin-home',
        'show_in_rest' => true,
    ));
}
add_action('init', 'pw_register_property_post_type');

// Add Meta Box for Longitude, Latitude, and Price
function pw_add_property_meta_boxes() {
    add_meta_box('property_details', 'Property Details', 'pw_property_details_callback', 'property');
}

function pw_property_details_callback($post) {
    $longitude = get_post_meta($post->ID, '_property_longitude', true);
    $latitude = get_post_meta($post->ID, '_property_latitude', true);
    $price = get_post_meta($post->ID, '_property_price', true);
    $city = get_post_meta($post->ID, '_property_city', true);
    $country = get_post_meta($post->ID, '_property_country', true);
    ?>
    <p><label>Longitude:</label>
        <input type="text" name="property_longitude" value="<?php echo esc_attr($longitude); ?>" /></p>
    <p><label>Latitude:</label>
        <input type="text" name="property_latitude" value="<?php echo esc_attr($latitude); ?>" /></p>
    <p><label>Price:</label>
        <input type="text" name="property_price" value="<?php echo esc_attr($price); ?>" /></p>
    <p><label>City:</label>
        <input type="text" name="property_city" value="<?php echo esc_attr($city); ?>" /></p>
    <p><label>Country:</label>
        <input type="text" name="property_country" value="<?php echo esc_attr($country); ?>" /></p>
    <?php
}

add_action('add_meta_boxes', 'pw_add_property_meta_boxes');

function pw_save_property_meta_data($post_id) {
    if (isset($_POST['property_longitude'])) {
        update_post_meta($post_id, '_property_longitude', sanitize_text_field($_POST['property_longitude']));
    }
    if (isset($_POST['property_latitude'])) {
        update_post_meta($post_id, '_property_latitude', sanitize_text_field($_POST['property_latitude']));
    }
    if (isset($_POST['property_price'])) {
        update_post_meta($post_id, '_property_price', sanitize_text_field($_POST['property_price']));
    }
    if (isset($_POST['property_city'])) {
        update_post_meta($post_id, '_property_city', sanitize_text_field($_POST['property_city']));
    }
    if (isset($_POST['property_country'])) {
        update_post_meta($post_id, '_property_country', sanitize_text_field($_POST['property_country']));
    }
}
add_action('save_post', 'pw_save_property_meta_data');

// Enqueue CSS
function pw_enqueue_styles() {
    wp_enqueue_style('pw-styles', plugin_dir_url(__FILE__) . 'assets/style.css');
}
add_action('wp_enqueue_scripts', 'pw_enqueue_styles');

function pw_get_weather_data() {
    $latitude = isset($_POST['latitude']) ? sanitize_text_field($_POST['latitude']) : '';
    $longitude = isset($_POST['longitude']) ? sanitize_text_field($_POST['longitude']) : '';
    $api_key = get_option('pw_openweather_api_key');

    if (empty($api_key)) {
        wp_send_json_error('API key not set');
    }

    $url = "https://api.openweathermap.org/data/2.5/weather?lat={$latitude}&lon={$longitude}&appid={$api_key}&units=metric";
    $response = wp_remote_get($url);

    if (is_wp_error($response)) {
        wp_send_json_error('Error fetching weather data');
    } else {
        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);

        if (isset($data['main'])) {
            $temp = $data['main']['temp'];
            $weather = $data['weather'][0]['description'];
            wp_send_json_success("Temperature: {$temp}°C, Condition: {$weather}");
        } else {
            wp_send_json_error('No weather data available');
        }
    }
}
add_action('wp_ajax_get_weather_data', 'pw_get_weather_data');
add_action('wp_ajax_nopriv_get_weather_data', 'pw_get_weather_data');

// Shortcode to Display Property List
function pw_display_property_list() {
    $args = array('post_type' => 'property', 'posts_per_page' => -1);
    $properties = get_posts($args);

    echo '<div class="property-list" style="display: flex; flex-wrap: wrap;">';
    foreach ($properties as $property) {
        $longitude = get_post_meta($property->ID, '_property_longitude', true);
        $latitude = get_post_meta($property->ID, '_property_latitude', true);
        $city = get_post_meta($property->ID, '_property_city', true);
        $country = get_post_meta($property->ID, '_property_country', true);
        $image = get_the_post_thumbnail($property->ID, 'thumbnail');

        echo '<div class="property-item" style="border: 1px solid #ddd; margin: 10px; padding: 10px; width: 300px;">';
        echo "<h3>{$property->post_title}</h3>";
        echo "<p>Longitude: {$longitude}</p>";
        echo "<p>Latitude: {$latitude}</p>";
        echo "<p>City: {$city}</p>";
        echo "<p>Country: {$country}</p>";
        echo $image;

        // Weather Button
        echo '<button class="weather-btn" onclick="showWeather(\'' . esc_js($latitude) . '\', \'' . esc_js($longitude) . '\')">Show Weather</button>';

        echo '<div class="weather-info" id="weather-info-' . $property->ID . '"></div>';
        echo '</div>';
    }
    echo '</div>';
}
add_shortcode('property_list', 'pw_display_property_list');

?>
