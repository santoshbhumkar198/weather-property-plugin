<?php
if (!defined('ABSPATH')) {
    exit; 
}

function pw_add_settings_page() {
    add_options_page(
        'Property Weather Settings',
        'Property Weather',
        'manage_options',
        'property-weather',
        'pw_settings_page_html'
    );
}
add_action('admin_menu', 'pw_add_settings_page');


function pw_settings_page_html() {
    ?>
    <div class="wrap">
        <h1>Property Weather Settings</h1>
        <form method="post" action="options.php">
            <?php
            settings_fields('property_weather_settings');
            do_settings_sections('property-weather');
            submit_button();
            ?>
        </form>
    </div>
    <?php
}

function pw_register_settings() {
    register_setting('property_weather_settings', 'pw_openweathermap_api_key');

    add_settings_section('pw_section', 'API Settings', null, 'property-weather');

    add_settings_field(
        'pw_openweathermap_api_key',
        'OpenWeatherMap API Key',
        'pw_api_key_field_html',
        'property-weather',
        'pw_section'
    );
}
add_action('admin_init', 'pw_register_settings');

// HTML for API Key Field
function pw_api_key_field_html() {
    $api_key = get_option('pw_openweathermap_api_key');
    ?>
    <input type="text" name="pw_openweathermap_api_key" value="<?php echo esc_attr($api_key); ?>" size="50" />
    <?php
}
