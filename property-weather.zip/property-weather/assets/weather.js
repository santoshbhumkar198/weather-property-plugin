jQuery(document).ready(function ($) {
  $(".weather-btn").on("click", function () {
    const lat = $(this).data("lat");
    const lon = $(this).data("lon");
    const apiKey = pw_weather.apiKey; // Use the localized API key

    if (!lat || !lon) {
      alert("Invalid latitude or longitude.");
      return;
    }

    const apiUrl = `https://api.openweathermap.org/data/2.5/weather?lat=${lat}&lon=${lon}&appid=${apiKey}&units=metric`;

    // Show loading message
    const weatherInfo = $(this).siblings(".weather-info");
    weatherInfo.html("Loading weather data...");

    // Fetch weather data
    $.get(apiUrl, function (data) {
      const weatherDescription = data.weather[0].description;
      const temperature = data.main.temp;
      const city = data.name;
      const country = data.sys.country;

      weatherInfo.html(`
              <p><strong>${city}, ${country}</strong></p>
              <p>Temperature: ${temperature} °C</p>
              <p>Condition: ${weatherDescription}</p>
          `);
    }).fail(function () {
      weatherInfo.html("Failed to load weather data.");
    });
  });
});
